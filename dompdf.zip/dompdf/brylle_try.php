<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>Patron Barcodes (8.5 X 11)</title>

	<link href="../bcodes.css" rel="stylesheet" type="text/css" />

<style type="text/css">

	body {

		background-color:#EEE;

		font-size:12px;

	}

	table {

		width:8.5in;

		background-color:#FFF;

	}

	td {

		width:2.8333333333333in;

		height:1.5714285714286in;

		vertical-align:top;

		border:thin dashed #CCC;

		border-radius:5px;

		padding:5px;

	}

	img {

		width:100%;

		height:50%;	

	}

</style>

</head>



<body>

<div align="center">

<table cellspacing="0" >

	<tr>

  <tr><td align='center' width='2.8333333333333' height='1.5714285714286'><label><b>MARYKNOLL HIGH SCHOOL OF PANABO Library</b></label>

				<img src='http://localhost/oll/admin/php_bcodes/genbcodesimgsrc/images/1200001173.png' alt='1200001173' />

				<label>1200001173</label><br />

				<label>ABUCAY, JENEBI L.</label></td><td align='center' width='2.8333333333333' height='1.5714285714286'><label><b>MARYKNOLL HIGH SCHOOL OF PANABO Library</b></label>

				<img src='http://localhost/oll/admin/php_bcodes/genbcodesimgsrc/images/1200001174.png' alt='1200001174' />

				<label>1200001174</label><br />

				<label>ASOY, MARJORIE L.</label></td><td align='center' width='2.8333333333333' height='1.5714285714286'><label><b>MARYKNOLL HIGH SCHOOL OF PANABO Library</b></label>

				<img src='http://localhost/oll/admin/php_bcodes/genbcodesimgsrc/images/1200001175.png' alt='1200001175' />

				<label>1200001175</label><br />

				<label>SERASPE, BRYLLE D.</label></td></tr>  </tr>

</table>

</div>

</body>

</html>



